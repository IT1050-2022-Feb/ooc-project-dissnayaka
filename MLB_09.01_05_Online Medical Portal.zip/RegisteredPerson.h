
class RegisteredPerson {
protected:
	string DOB;
	string bloodType;
	string roomNum;
	Doctor* dr;
public:
	RegisteredPerson();
	RegisteredPerson(string date, string btype, string room);
	void displayAll();
};
