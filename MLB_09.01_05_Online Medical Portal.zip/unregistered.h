#pragma once
#include<iostream>
#include<cstring>

class UnregisterPatient {
	protected:
		char Name[30];
		int NIC;
		int Age;
		char Address[30];
	public:
		void UnregisteredPatient(){}
		void UnregisteredPatient(char* P_Name, int P_NIC, int P_Age, char* P_Address);
		void registerUser();
};
