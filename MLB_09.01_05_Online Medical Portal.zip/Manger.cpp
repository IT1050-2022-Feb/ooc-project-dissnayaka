#include <iostream>
#include <cstring>
#include "Employee.h"
#include "Manger.h"
#include "Report.h"
using namespace std;



Manger::Manger() : Employee()
{
    strcpy_s(Manger_Type, "");
    R = 0;
}

Manger::Manger(int Eid, char *Ename, char *Eadd, char Email, Report *repo, char *M_type) : Employee(Eid, Ename, Eadd, Email)
{
    strcpy_s(Manger_Type, "M_type");
    R = repo;
}

void Manger::display_Manger()
{
    display_Emaployee();
    R->displayReport();
    cout << Manger_Type << endl;
}


