#pragma once
class Appointment
{
private:
	char appointmentID[10];
	char appointmentDate[15];
	char appointmentTime[15];
	char appointmentCategory[30];

public:
	Appointment();
	Appointment(const char aID[], const char aDate[], const char aTime[], const char aCategory[]);
	void displayAppointmentDetails();
	~Appointment();

};

