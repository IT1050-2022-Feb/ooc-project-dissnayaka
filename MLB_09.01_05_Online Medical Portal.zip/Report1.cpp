#include <iostream>
#include "Report1.h"
#include <cstring>
using namespace std;

void Report1::Report()
{
	
}

void Report1::Report(int r_id, char r_name[])
{
	int Report_id = r_id;
	strcpy(Report_name, r_name);
}

void Report1::generate_Report()
{
	cout << "Report ID : " << Report_id << endl;
	cout << "Report Name : " << Report_name << endl;
}
