#include "Appointment.h"
#include <cstring>
#include <iostream>
using namespace std;

Appointment::Appointment() {
	strcpy_s(appointmentID, "");
	strcpy_s(appointmentDate, "");
	strcpy_s(appointmentTime, "");
	strcpy_s(appointmentCategory, "");

}

Appointment::Appointment(const char aID[], const char aDate[], const char aTime[], const char aCategory[]) {
	strcpy_s(appointmentID, aID);
	strcpy_s(appointmentDate, aDate);
	strcpy_s(appointmentTime, aTime);
	strcpy_s(appointmentCategory, aCategory);

}

void Appointment::displayAppointmentDetails() {

}

Appointment :: ~Appointment() {
	//destructer
}
