#pragma once
#include <iostream>
#include <cstring>


class Custom_support: public Employee
{
private:
    Registered_Patient *Rp;
    int Custom_support_service_ID;

public:
    Custom_support();
    Custom_support(int Eid, char *Ename, char *Eadd, char Email, Registered_Patient *reji_p, int cssi);
    void display_Registered_Patient();
};


