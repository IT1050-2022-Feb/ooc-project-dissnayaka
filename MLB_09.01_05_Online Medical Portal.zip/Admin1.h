#pragma once
#include<iostream>
using namespace std;

class ADMIN: Employee {
private:
	char AdminType[50];

public:
	void Admin();
	void Admin(char* Ename, int Eid, char* Eadd, char Email, char* atype);
	void manage_appointments();
	void manage_doctors();
	void manage_patients();
	void create_reports();
};

