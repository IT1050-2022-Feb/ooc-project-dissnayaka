#include <iostream>
#include<cstring>
#include "payment.h"
using namespace std;

Payment::Payment() {
	strcpy_s(paymentID, "");
	strcpy_s(paymentType, "");
	int paymentFee = 0;
}
Payment::Payment(const char pID[], const char pType[], int pFee) {
	strcpy_s(paymentID, pID);
	strcpy_s(paymentType, pType);
	int paymentFee = pFee;
}

void Payment::paymentDetails() {

}

void Payment::calcPayment() {

}

void Payment::displayPaymentDetails() {

}

Payment:: ~Payment() {
	//Destructor
}

