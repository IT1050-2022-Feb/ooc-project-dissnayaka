#pragma once
#include <iostream>
class Report1 {
private:
	int Report_id;
	char Report_name[20];


public:
	void Report();
	void Report(int r_id, char r_name[]);
	void generate_Report();
};
