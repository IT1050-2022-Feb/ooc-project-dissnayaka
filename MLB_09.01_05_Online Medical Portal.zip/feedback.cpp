#include"feedback.h"
#include<iostream>
#include<cstring>
using namespace std;

void Feed::Feedback() {
	FeedbackID = 0;
	strcpy_s(Description, "");
}
void Feed::Feedback(int F_ID, char* Des) {
	FeedbackID = F_ID;
	strcpy_s(Description, Des);
}
void displayFeedback(){}