#include <iostream>
#include <cstring>
#include "Report1.h"
#include "Report.h"
#include "Admin.h"
using namespace std;

int main()
{
	Report1 r1;

	r1.Report(10, (char*)"Payment Reports");
	r.generate_Report();

	cout << "\n" << endl;
	cout << "--------------------------------" << endl;

}


