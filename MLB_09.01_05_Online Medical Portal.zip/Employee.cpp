#include <iostream>
#include <cstring>
#include "Employee.h"
using namespace std;

Employee::Employee()
{
    Employee_ID = 0;
    strcpy_s(Employee_Name, "");
    strcpy_s(Employee_Addres, "");
    strcpy_s(Employee_Email, "");
}

Employee::Employee(int Eid, char *Ename, char *Eadd, char Email)
{
    Employee_ID = Eid;
    strcpy_s(Employee_Name, "Ename");
    strcpy_s(Employee_Addres, "Eadd");
    strcpy_s(Employee_Email, "Email");
}

void Employee::display_Emaployee()
{
    cout << "Employee_ID" << endl;
    cout << "Employee_Name" << endl;
    cout << "Employee_Addres" << endl;
    cout << "Employee_Email" << endl;
}
