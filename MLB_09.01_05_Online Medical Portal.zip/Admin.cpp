#include <iostream>
#include "Admin1.h"
#include "Appointment.h"
#include "Employee.h"
#include "registeredPerson.h"
#include "Report.h"
#include "Doctor.h"


using namespace std;

int main()
{
	ADMIN A1;

	A1.Admin("Chinthaka", "010", "Athurugiriya", "admin10@gmail.com", "Securityt System Admin");
	cout << " **************************" << endl;

	Appointment Ap1;

	Ap1.manage_appointments();

	Doctor Do1;

	Do1.Doctor()

	cout << "\n" << endl;
	cout << "--------------------------------" << endl;

	RegisteredPerson rg1;

	rg1.RegisteredPerson();

	cout << "\n" << endl;
	cout << "--------------------------------" << endl;

	Report rp1;

	rp1.Report();

	cout << "\n" << endl;
	cout << "--------------------------------" << endl;

}
