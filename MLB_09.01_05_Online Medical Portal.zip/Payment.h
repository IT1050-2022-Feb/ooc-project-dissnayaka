#pragma once
	class Payment {
	private:
		//Payment();
		char paymentID[10];
		char paymentType[30];
		int paymentFee[];

		//commission* com;


	public:
		Payment();
		Payment(const char pID[], const char pType[], int pFee);
		void paymentDetails();
		void calcPayment();
		void displayPaymentDetails();

		~Payment();


};


