#include "Register.h"
using namespace std;
#include <string>

RegisteredPerson::RegisteredPerson() {
	DOB = "12-12-2012";
	bloodType = "O positive";
	roomNum = "B202";
}

RegisteredPerson::RegisteredPerson(string date, string btype, string room) {
	DOB = date;
	bloodType = btype;
	roomNum = room;
}

void RegisteredPerson::displayAll() {
	cout << DOB << endl;
	cout << bloodType << endl;
	cout << roomNum << endl;
}
