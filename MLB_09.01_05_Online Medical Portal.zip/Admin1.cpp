#include <iostream>
#include <cstring>
#include "Admin1.h"
#include "Employee.h"
#include "Appointment.h"


void ADMIN::Admin()
{
	strcpy_s(AdminType, "");
}

void ADMIN::Admin(char* Ename, int Eid, char* Eadd, char Email, char* atype)
{
	strcpy_s(AdminType, "atype");

}

void ADMIN::manage_appointments()
{
	cout << "Appointment ID : " << endl;
	cout << "Appointment category : " << endl;
}

void ADMIN::manage_doctors()
{
	cout << "Doctor ID : " << endl;
	cout << "Doctor Name : " << endl;
}

void ADMIN::manage_patients()
{
	cout << "Patient NIC : " << endl;
	cout << "Patient Name : " << endl;
}

void ADMIN::create_reports()
{
	cout << "Report ID : " << endl;
	cout << "Report Name : " << endl;
}