#pragma once
#include <iostream>
#include <cstring>
using namespace std;


class Manager: public Employee
{
private:
    Report *R;
    char Manger_Type[20];

public:
    Manger(){};
    Manger(int Eid, char *Ename, char *Eadd, char Email, Report *repo, char *M_type);
    void display_Manger();
};

