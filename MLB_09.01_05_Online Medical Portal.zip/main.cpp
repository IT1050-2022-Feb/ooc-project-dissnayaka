#include <iostream>
#include "Payment.h"
#include "Employee.h"
#include "Custom_support.h"
#include "Registered_Patient.h"
#include "Manger.h"
#include "Doctor.h"
using namespace std;




int main()
{
	Payment* pay;
	pay = new Payment();

	//method calling
	pay->displayPaymentDetails();
	pay->calcPayment();


	//delete dynamic object
	delete pay;


        Employee E;
        E.Employee("E1", "Ishara", "Knady", "Ishara@gmail.com");
        E.display_Emaployee;
        cout << " **************************" << endl;

  
        Manger *M = new Manger("M1", "Ishara", "Knady", "Ishara@gmail.com", R, "Gread A");
        M->display_Manger();
        cout << " **************************" << endl;
        delete M;
  
        Custom_support * 01 = new Custom_support("C001", "Tharindu", "Colambo", "tharindu@gmail.com", RP1, "CSSI01");

  UnregisterPatient U1;
	U1.UnregisteredPatient("Oshadhi", 200074000423, 24, "113/18,Peradeniya road,Kandy");
	U1.registerUser();

	Feed F1;
	F1.Feedback(001, "Good");
	F1.displayFeedback();
	return 0;
  //doctor 
  Doctor d1; 
  d1.setDoctorDetails(001,"max","colombo","mail@gmail.com","specialist");
	d1.displayDOC();
  /// registered patient class goes on here
  RegisteredPerson rp1("12-04-2022","Opositive","G564");
	rp1.displayAll();

  //Admin 

  ADMIN A1;

	A1.Admin("Chinthaka", "010", "Athurugiriya", "admin10@gmail.com", "Securityt System Admin");
	cout << " **************************" << endl;

	Appointment Ap1;

	Ap1.manage_appointments();

	Doctor Do1;

	Do1.Doctor()

	cout << "\n" << endl;
	cout << "--------------------------------" << endl;

	RegisteredPerson rg1;

	rg1.RegisteredPerson();

	cout << "\n" << endl;
	cout << "--------------------------------" << endl;

	Report rp1;

	rp1.Report();

	cout << "\n" << endl;
	cout << "--------------------------------" << endl;

  //Report

  	Report1 r1;

	r1.Report(10, (char*)"Payment Reports");
	r1.generate_Report();

	cout << "\n" << endl;
	cout << "--------------------------------" << endl;
}

