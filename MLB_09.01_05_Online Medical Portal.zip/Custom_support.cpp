#include <iostream>
#include <cstring>
#include "Employee.h"
#include "Custom_support.h"
#include "Registered_Patient.h"
using namespace std;

Custom_support::Custom_support() : Employee()
{
    Custom_support_service_ID = 0;
    Rp = 0;
}

Custom_support::Custom_support(int Eid, char *Ename, char *Eadd, char Email, Registered_Patient *reji_p, int cssi) : Employee(Eid, Ename, Eadd, Email)
{
    Custom_support_service_ID = cssi;
    Rp = reji_p;
}

void Custom_support::display_Registered_Patient()
{
    display_Emaployee();
    Rp->displayReport();
    cout << Custom_support_service_ID << endl;
}
