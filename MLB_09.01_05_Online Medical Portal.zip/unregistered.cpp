#include"unregistered.h"
#include"feedback.h";
#include<iostream>
#include<cstring>
using namespace std;

void UnregisterPatient::UnregisteredPatient() {
	strcpy_s(Name,"");
	NIC = 0;
	Age = 0;
	strcpy_s(Address,"");
}

void UnregisterPatient::UnregisteredPatient(char* P_Name, int P_NIC, int P_Age, char* P_Address) {
	strcpy_s(Name, P_Name);
	NIC = P_NIC;
	Age = P_Age;
	strcpy_s(Address,P_Address);
}
void UnregisterPatient::registerUser() {
	cout << "Name" << endl;
	cout << "NIC" << endl;
	cout << "Age" << endl;
	cout << "Address" << endl;
}