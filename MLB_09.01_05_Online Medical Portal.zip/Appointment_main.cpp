#include "Appointment.h"
#include <iostream>
using namespace std;

int main()
{
	Appointment* appointment;
	appointment = new Appointment();

	//method calling
	appointment->displayAppointmentDetails();

	//delete dynamic object
	delete appointment;

}

