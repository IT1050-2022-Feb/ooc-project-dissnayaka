#pragma once
#include <iostream>
#include <cstring>

class Employee
{
protected:
    int Employee_ID;
    char Employee_Name[30];
    char Employee_Addres[40];
    char Employee_Email[50];

public:
    Employee() {}
    Employee(int Eid, char *Ename, char *Eadd, char Email);
    void display_Emaployee();
};

