#pragma once
#include<iostream>
#include<cstring>
using namespace std;

class Feed {
private:
	int FeedbackID;
	char Description[50];
	Feed* feedback[SIZE];
public:
	void Feedback();
	void Feedback(int F_ID, char* Des);
	void displayFeedback();
};