
class Doctor:public Employee{
	private:
		char specialization[30];
	public:
		void setDoctorDetails(int dID , const char Dname[30], const char address[40], const char mail[50], const char spec[30]){
			Employee_ID = dID;
			strcpy(Employee_Name, Dname);
			strcpy(Employee_Addres, address);
			strcpy(Employee_Email, mail);
			strcpy(specialization, spec);
		}
		void displayDOC(){
			cout << Employee_ID << endl;
		}
};
class Employee {
protected:
	int Employee_ID;
	string Employee_Name;
	string Employee_Addres;
	string Employee_Email;

public:
	Employee();
	Employee(int Eid, string Ename, string Eadd, string Email);
	void display_Emaployee();
};

Employee::Employee() {
	Employee_ID = 000;
	Employee_Name = "Migara";
	Employee_Addres = "Anuradhapura";
	Employee_Email = "migara@mail.com";
}

Employee::Employee(int Eid, string Ename, string Eadd, string Email) {
	Employee_ID = Eid;
	Employee_Name = Ename;
	Employee_Addres = Eadd;
	Employee_Email = Email;
}

void Employee::display_Emaployee()
{
	cout << "Employee_ID" << endl;
	cout << "Employee_Name" << endl;
	cout << "Employee_Addres" << endl;
	cout << "Employee_Email" << endl;
}


class Doctor:public Employee {
private:
	string specialization;
public:
	Doctor();
	void  setDoctorDetails(int Eid, string Ename, string Eadd, string Email);
	void displayDetails();
};

Doctor::Doctor(){
	Employee_Name = "default";
	Employee_Addres = "default";
}

void Doctor::setDoctorDetails(int Eid, string Ename, string Eadd, string Email) {
	Employee_ID = Eid;
	Employee_Name = Ename;
	Employee_Addres = Eadd;
	Employee_Email = Email;
}

void Doctor::displayDetails() {
	cout << Employee_ID << endl;
	cout << Employee_Name << endl;
	cout << Employee_Addres << endl;
	cout << Employee_Email << endl;
}